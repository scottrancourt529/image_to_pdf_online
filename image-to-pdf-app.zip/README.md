# Image to PDF — Offline Version

Thank you for downloading the offline edition of **Image to PDF**.

## How to Use

1. Extract the ZIP file to any folder on your computer.
2. Open the extracted folder.
3. Launch the app by opening **index.html** in your browser.

This tool runs entirely on your device.  
Your images are never uploaded anywhere.

## Notes

- Works in any modern browser (Chrome, Edge, Firefox, Brave, etc.)
- No installation required
- No internet connection needed